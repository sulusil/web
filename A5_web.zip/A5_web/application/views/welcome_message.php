<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h3> Tabel Data Mahasiswa</h3>
<table>
	<thead>
		<tr>
			<th> no</th>
			<th> nim</th>
			<th>nama</th> 
			<th>email</th>
		</tr>
	</thead>
	<TBODY>
		<?php 
		$no = 1;
		foreach($mahasiswa -> result (as $m)); ?>
		
		?>
		<tr>
			<td> <?php = $no ++ ?></td>
			<td> <?php = $m -> id ?></td>
			<td> <?php = $m -> nama ?></td>
			<td> <?php = $m -> email ?></td>
		</tr>
	<?php endforeach; ?>

	</TBODY>
</table>
</body>
</html>

